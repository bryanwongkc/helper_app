# Help Helper App

An offline-friendly task, recipe, and grocery helper app for domestic workers.