
// RecipeCard.jsx
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function RecipeCard({ recipe, onAdd }) {
  return (
    <Card className="my-4">
      <CardContent className="p-4">
        <h2 className="font-bold text-lg mb-2">{recipe.title}</h2>
        <ul className="text-sm mb-2 list-disc list-inside">
          {recipe.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
        </ul>
        <ol className="text-sm list-decimal list-inside mb-2">
          {recipe.steps.map((step, i) => <li key={i}>{step}</li>)}
        </ol>
        <Button size="sm" onClick={() => onAdd(recipe.ingredients, recipe.title)}>
          Add Ingredients to Grocery
        </Button>
      </CardContent>
    </Card>
  );
}
