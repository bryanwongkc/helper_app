
// GroceryItem.jsx
import { Checkbox } from "@/components/ui/checkbox";

export default function GroceryItem({ item, checked, onToggle }) {
  return (
    <li className="flex items-center gap-2">
      <Checkbox checked={checked} onCheckedChange={onToggle} />
      <span className={checked ? "line-through text-gray-400" : ""}>{item}</span>
    </li>
  );
}
