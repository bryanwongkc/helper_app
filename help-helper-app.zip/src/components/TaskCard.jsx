
// TaskCard.jsx
import { Card, CardContent } from "@/components/ui/card";

export default function TaskCard({ task, onClick }) {
  return (
    <Card key={task.id} className="my-2 cursor-pointer" onClick={() => onClick(task)}>
      <CardContent className="p-4">
        <h2 className="font-bold text-lg">{task.title}</h2>
      </CardContent>
    </Card>
  );
}
