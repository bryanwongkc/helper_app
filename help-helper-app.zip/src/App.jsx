
// App.jsx
import { useState, useEffect } from "react";
import { Toggle } from "@/components/ui/toggle";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RecipesPage from "./pages/RecipesPage";
import TasksPage from "./pages/TasksPage";
import GroceryPage from "./pages/GroceryPage";
import recipesData from "./data/recipes.json";
import tasksData from "./data/tasks.json";

export default function HelpHelperApp() {
  const [lang, setLang] = useState("en");
  const [recipes, setRecipes] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [grocery, setGrocery] = useState([]);
  const [checked, setChecked] = useState({});
  const [customItem, setCustomItem] = useState("");
  const [selectedTask, setSelectedTask] = useState(null);

  useEffect(() => {
    setRecipes(recipesData);
    setTasks(tasksData);
  }, []);

  return (
    <div className="p-4 font-sans max-w-md mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-semibold">Help Helper</h1>
        <Toggle pressed={lang === "fil"} onPressedChange={() => setLang(lang === "en" ? "fil" : "en")}> 
          {lang === "en" ? "🇬🇧 English" : "🇵🇭 Filipino"}
        </Toggle>
      </div>
      <Tabs defaultValue="tasks" className="w-full">
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="recipes">Recipes</TabsTrigger>
          <TabsTrigger value="grocery">Grocery</TabsTrigger>
        </TabsList>
        <TabsContent value="tasks">
          <TasksPage tasks={tasks} lang={lang} selectedTask={selectedTask} setSelectedTask={setSelectedTask} />
        </TabsContent>
        <TabsContent value="recipes">
          <RecipesPage recipes={recipes} addToGrocery={(ingredients, recipeName) => {
            const newItems = ingredients.map(item => ({ item, recipe: recipeName }))
              .filter(({ item }) => !grocery.some(g => g.item === item));
            setGrocery([...grocery, ...newItems]);
          }} />
        </TabsContent>
        <TabsContent value="grocery">
          <GroceryPage
            grocery={grocery}
            setGrocery={setGrocery}
            checked={checked}
            setChecked={setChecked}
            customItem={customItem}
            setCustomItem={setCustomItem}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
