
// TasksPage.jsx
import TaskCard from "../components/TaskCard";
import { Card, CardContent } from "@/components/ui/card";

export default function TasksPage({ tasks, lang, selectedTask, setSelectedTask }) {
  return (
    <div>
      {tasks.map(task => (
        <TaskCard key={task.id} task={task} onClick={setSelectedTask} />
      ))}

      {selectedTask && (
        <Card className="my-4 border-2 border-blue-400">
          <CardContent className="p-4">
            <h2 className="font-bold text-xl mb-2">{selectedTask.title}</h2>
            <p className="text-gray-700 text-sm whitespace-pre-line">{selectedTask[lang]}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
