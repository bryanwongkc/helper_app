
// RecipesPage.jsx
import RecipeCard from "../components/RecipeCard";

export default function RecipesPage({ recipes, addToGrocery }) {
  return (
    <div>
      {recipes.map(recipe => (
        <RecipeCard key={recipe.id} recipe={recipe} onAdd={addToGrocery} />
      ))}
    </div>
  );
}
