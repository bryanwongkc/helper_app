
// GroceryPage.jsx
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import GroceryItem from "../components/GroceryItem";

export default function GroceryPage({ grocery, setGrocery, checked, setChecked, customItem, setCustomItem }) {
  function toggleItem(item) {
    setChecked(prev => ({ ...prev, [item]: !prev[item] }));
  }

  function clearGrocery() {
    setGrocery([]);
    setChecked({});
  }

  function addCustomItem() {
    if (customItem.trim()) {
      setGrocery([...grocery, { item: customItem.trim(), recipe: "Custom" }]);
      setCustomItem("");
    }
  }

  const grouped = grocery.reduce((acc, item) => {
    acc[item.recipe] = acc[item.recipe] || [];
    acc[item.recipe].push(item.item);
    return acc;
  }, {});

  return (
    <div>
      {grocery.length > 0 && (
        <div className="flex justify-end mb-2">
          <Button variant="outline" size="sm" onClick={clearGrocery}>Clear All</Button>
        </div>
      )}
      <div className="flex gap-2 mb-4">
        <Input placeholder="Add custom item" value={customItem} onChange={e => setCustomItem(e.target.value)} />
        <Button size="sm" onClick={addCustomItem}>Add</Button>
      </div>
      {grocery.length === 0 && <p className="text-sm text-center text-gray-500">No items added yet.</p>}
      {Object.entries(grouped).map(([recipe, items]) => (
        <div key={recipe} className="mb-4">
          <h3 className="font-semibold text-md mb-1">{recipe}</h3>
          <ul className="text-sm space-y-1">
            {items.map((item, idx) => (
              <GroceryItem
                key={idx}
                item={item}
                checked={checked[item]}
                onToggle={() => toggleItem(item)}
              />
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
